"""区域启用（Account Management API）的测试。

覆盖：account 客户端固定 us-east-1 且代理透传、状态查询与错误映射、
启用幂等（已启用/进行中/Conflict）、路由级 status/enable 接口。
不调真实 AWS。运行：
    backend/.venv/bin/python -m unittest discover -s tests -v
"""
import os
import sys
import unittest
from unittest.mock import Mock, patch

# fail-fast：配置为必填，测试须先设置合法的测试值再导入 app 代码。
os.environ.setdefault("SECRET_KEY", "test-only-secret-key-0123456789abcdef")
os.environ.setdefault("ENCRYPTION_KEY", "WWevy1rc32FPbz51VPopb5qw2SqEo-6VNp0jX1b4_EE=")
os.environ.setdefault("ADMIN_PASSWORD", "TestAdminPass123!")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from botocore.exceptions import BotoCoreError, ClientError

from app.services.account import AccountError, enable_region, get_region_opt_status, make_account_client

PROXY = "http://alice:s3cret@proxy.example.com:8080"


def _client_error(code: str, op: str = "GetRegionOptStatus") -> ClientError:
    return ClientError({"Error": {"Code": code, "Message": f"{code} message"}}, op)


class TestMakeAccountClient(unittest.TestCase):
    def test_fixed_us_east_1_and_proxy_passthrough(self):
        with patch("app.services.account.boto3.client") as mk:
            make_account_client("AKID", "SK", PROXY)
            args, kwargs = mk.call_args
            self.assertEqual(args[0], "account")
            self.assertEqual(kwargs["region_name"], "us-east-1")
            self.assertEqual(kwargs["config"].proxies, {"http": PROXY, "https": PROXY})
        with patch("app.services.account.boto3.client") as mk:
            make_account_client("AKID", "SK")
            _, kwargs = mk.call_args
            self.assertEqual(kwargs["config"].proxies, {"http": None, "https": None})


class TestGetRegionOptStatus(unittest.TestCase):
    def _mock_client(self, **behaviors):
        client = Mock()
        for name, value in behaviors.items():
            attr = getattr(client, name)
            if isinstance(value, Exception):
                attr.side_effect = value
            else:
                attr.return_value = value
        return client

    def test_returns_status(self):
        for status in ("ENABLED", "ENABLING", "DISABLED", "ENABLED_BY_DEFAULT"):
            client = self._mock_client(
                get_region_opt_status={"RegionOptStatus": status}
            )
            with patch("app.services.account.make_account_client", return_value=client):
                self.assertEqual(get_region_opt_status("AKID", "SK", "ap-east-1"), status)

    def test_access_denied_friendly(self):
        client = self._mock_client(
            get_region_opt_status=_client_error("AccessDeniedException")
        )
        with patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                get_region_opt_status("AKID", "SK", "ap-east-1")
            self.assertIn("account:EnableRegion", ctx.exception.message)
            self.assertEqual(ctx.exception.code, "AccessDeniedException")

    def test_invalid_credentials_friendly(self):
        client = self._mock_client(
            get_region_opt_status=_client_error("UnrecognizedClientException")
        )
        with patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                get_region_opt_status("AKID", "SK", "ap-east-1")
            self.assertIn("凭证无效", ctx.exception.message)

    def test_connection_error(self):
        client = self._mock_client(get_region_opt_status=BotoCoreError())
        with patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                get_region_opt_status("AKID", "SK", "ap-east-1")
            self.assertIn("连接错误", ctx.exception.message)

    def test_connection_error_masks_proxy_password(self):
        # U-2：BotoCoreError 的异常串可能原样带上含密码的代理 URL，
        # AccountError 里不能出现密码明文。
        from botocore.exceptions import EndpointConnectionError

        client = self._mock_client(
            get_region_opt_status=EndpointConnectionError(
                endpoint_url="http://alice:s3cret@proxy.example.com:8080"
            )
        )
        with patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                get_region_opt_status("AKID", "SK", "ap-east-1")
            self.assertNotIn("s3cret", ctx.exception.message)
            self.assertIn("***:***@", ctx.exception.message)

    def test_client_error_message_masks_proxy_password(self):
        client = self._mock_client(
            get_region_opt_status=ClientError(
                {
                    "Error": {
                        "Code": "SomeCode",
                        "Message": "boom http://alice:s3cret@proxy.example.com:8080",
                    }
                },
                "GetRegionOptStatus",
            )
        )
        with patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                get_region_opt_status("AKID", "SK", "ap-east-1")
            self.assertNotIn("s3cret", ctx.exception.message)
            self.assertIn("***:***@", ctx.exception.message)

    def test_generic_error_masks_proxy_password(self):
        client = self._mock_client(
            get_region_opt_status=RuntimeError(
                "boom http://alice:s3cret@proxy.example.com:8080"
            )
        )
        with patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                get_region_opt_status("AKID", "SK", "ap-east-1")
            self.assertNotIn("s3cret", ctx.exception.message)


class TestEnableRegion(unittest.TestCase):
    def test_already_enabled_returns_without_calling(self):
        client = Mock()
        with patch(
            "app.services.account.get_region_opt_status", return_value="ENABLED"
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLED")
            client.enable_region.assert_not_called()

    def test_enabling_returns_enabling(self):
        client = Mock()
        with patch(
            "app.services.account.get_region_opt_status", return_value="ENABLING"
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLING")
            client.enable_region.assert_not_called()

    def test_disabled_enables_and_confirms(self):
        client = Mock()
        with patch(
            "app.services.account.get_region_opt_status",
            side_effect=["DISABLED", "ENABLING"],
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLING")
            client.enable_region.assert_called_once_with(RegionName="ap-east-1")

    def test_disabled_enables_to_enabled(self):
        client = Mock()
        with patch(
            "app.services.account.get_region_opt_status",
            side_effect=["DISABLED", "ENABLED"],
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLED")

    def test_conflict_treated_as_enabling(self):
        client = Mock()
        client.enable_region.side_effect = _client_error("ConflictException", "EnableRegion")
        with patch(
            "app.services.account.get_region_opt_status", return_value="DISABLED"
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLING")

    def test_validation_error_rechecks_status(self):
        client = Mock()
        client.enable_region.side_effect = _client_error("ValidationException", "EnableRegion")
        with patch(
            "app.services.account.get_region_opt_status",
            side_effect=["DISABLED", "ENABLED"],
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLED")

    def test_access_denied_friendly(self):
        client = Mock()
        client.enable_region.side_effect = _client_error("AccessDeniedException", "EnableRegion")
        with patch(
            "app.services.account.get_region_opt_status", return_value="DISABLED"
        ), patch("app.services.account.make_account_client", return_value=client):
            with self.assertRaises(AccountError) as ctx:
                enable_region("AKID", "SK", "ap-east-1")
            self.assertIn("account:EnableRegion", ctx.exception.message)

    def test_status_check_denied_then_enable_proceeds(self):
        # 读状态没权限时不直接拦：直接尝试启用。
        client = Mock()
        with patch(
            "app.services.account.get_region_opt_status",
            side_effect=[
                AccountError("权限不足", code="AccessDeniedException"),
                AccountError("权限不足", code="AccessDeniedException"),
            ],
        ), patch("app.services.account.make_account_client", return_value=client):
            self.assertEqual(enable_region("AKID", "SK", "ap-east-1"), "ENABLING")
            client.enable_region.assert_called_once_with(RegionName="ap-east-1")


# ---- 路由级测试：内存库 + TestClient（沿用 test_proxy.py 的搭法）----
from fastapi.testclient import TestClient  # noqa: E402

from app.database import Base, get_db  # noqa: E402
from app.main import app  # noqa: E402
from app.models import AwsCredential, OperationLog, User  # noqa: E402
from app.rate_limit import region_limiter  # noqa: E402
from app.security import encrypt_secret, hash_password  # noqa: E402


def _make_session():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy.pool import StaticPool

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


class _ClientCase(unittest.TestCase):
    def setUp(self):
        self.db = _make_session()
        self._orig = dict(app.dependency_overrides)
        session = self.db

        def _override():
            try:
                yield session
            finally:
                pass

        app.dependency_overrides[get_db] = _override
        self.client = TestClient(app)

    def tearDown(self):
        app.dependency_overrides.clear()
        app.dependency_overrides.update(self._orig)
        self.db.close()

    def _login(self, username, password):
        r = self.client.post("/api/auth/login", json={"username": username, "password": password})
        self.assertEqual(r.status_code, 200, r.text)
        return r.json()["access_token"]

    def _auth(self, token):
        return {"Authorization": f"Bearer {token}"}

    def _add_credential(self, user_id: int) -> int:
        cred = AwsCredential(
            user_id=user_id,
            access_key_id_enc=encrypt_secret("AKIAIOSFODNN7EXAMPLE"),
            secret_access_key_enc=encrypt_secret("wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"),
            is_default=True,
        )
        self.db.add(cred)
        self.db.commit()
        self.db.refresh(cred)
        return cred.id


class TestRegionEndpoints(_ClientCase):
    def setUp(self):
        super().setUp()
        region_limiter.reset()
        user = User(username="regalice", password_hash=hash_password("AlicePass123!x"))
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        self.token = self._login("regalice", "AlicePass123!x")
        self.cid = self._add_credential(user.id)

    def test_status_disabled(self):
        with patch(
            "app.routers.credentials.acct.get_region_opt_status", return_value="DISABLED"
        ):
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
            self.assertEqual(r.json(), {"region": "ap-east-1", "status": "DISABLED", "message": None})

    def test_status_unknown_on_account_error(self):
        with patch(
            "app.routers.credentials.acct.get_region_opt_status",
            side_effect=AccountError("AWS 凭证无效：请检查", code="UnrecognizedClientException"),
        ):
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
            self.assertEqual(r.json()["status"], "UNKNOWN")
            self.assertIn("凭证无效", r.json()["message"])

    def test_status_404(self):
        r = self.client.get(
            "/api/credentials/9999/regions/ap-east-1/status", headers=self._auth(self.token)
        )
        self.assertEqual(r.status_code, 404, r.text)

    def test_status_bad_region(self):
        for bad in ("not-a-region", "us_east_1", "AP-EAST-1"):
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/{bad}/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 400, bad)

    def test_enable_enabling(self):
        with patch(
            "app.routers.credentials.acct.enable_region", return_value="ENABLING"
        ):
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
            self.assertEqual(r.json()["status"], "ENABLING")

    def test_enable_enabled(self):
        with patch(
            "app.routers.credentials.acct.enable_region", return_value="ENABLED"
        ):
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
            self.assertEqual(r.json()["status"], "ENABLED")

    def test_enable_access_denied_400(self):
        with patch(
            "app.routers.credentials.acct.enable_region",
            side_effect=AccountError("权限不足：密钥需要", code="AccessDeniedException"),
        ):
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 400, r.text)
            self.assertIn("权限不足", r.json()["detail"])

    def test_enable_404_and_bad_region(self):
        r = self.client.post(
            "/api/credentials/9999/regions/ap-east-1/enable", headers=self._auth(self.token)
        )
        self.assertEqual(r.status_code, 404, r.text)
        r = self.client.post(
            f"/api/credentials/{self.cid}/regions/bad_region/enable",
            headers=self._auth(self.token),
        )
        self.assertEqual(r.status_code, 400, r.text)

    def test_status_generic_error_is_sanitized(self):
        # U-2：路由通用 except 原样回显异常串，含密码的代理 URL 会进
        # 200 的 message；现在要脱敏。
        with patch(
            "app.routers.credentials.acct.get_region_opt_status",
            side_effect=RuntimeError("boom http://alice:s3cret@proxy.example.com:8080"),
        ):
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
            self.assertNotIn("s3cret", r.json()["message"])
            self.assertIn("***:***@", r.json()["message"])

    def test_enable_generic_error_is_sanitized(self):
        with patch(
            "app.routers.credentials.acct.enable_region",
            side_effect=RuntimeError("boom http://alice:s3cret@proxy.example.com:8080"),
        ):
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 400, r.text)
            self.assertNotIn("s3cret", r.json()["detail"])
            self.assertIn("***:***@", r.json()["detail"])

    def test_status_rate_limited(self):
        # U-4：状态查询 10 次/分钟；第 11 次 429。
        with patch(
            "app.routers.credentials.acct.get_region_opt_status", return_value="DISABLED"
        ):
            for _ in range(10):
                r = self.client.get(
                    f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                    headers=self._auth(self.token),
                )
                self.assertEqual(r.status_code, 200, r.text)
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 429, r.text)

    def test_enable_rate_limited(self):
        # U-4：启用 5 次/分钟；第 6 次 429。
        with patch(
            "app.routers.credentials.acct.enable_region", return_value="ENABLING"
        ):
            for _ in range(5):
                r = self.client.post(
                    f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                    headers=self._auth(self.token),
                )
                self.assertEqual(r.status_code, 200, r.text)
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 429, r.text)

    def test_enable_logs_operation(self):
        # U-4：enable 成功记操作日志。
        with patch(
            "app.routers.credentials.acct.enable_region", return_value="ENABLING"
        ):
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
        logs = (
            self.db.query(OperationLog)
            .filter(OperationLog.action == "enable_region")
            .all()
        )
        self.assertEqual(len(logs), 1)
        self.assertEqual(logs[0].status, "success")
        self.assertEqual(logs[0].region, "ap-east-1")

    def test_enable_failure_logs_operation(self):
        # U-4：enable 失败也记操作日志。
        with patch(
            "app.routers.credentials.acct.enable_region",
            side_effect=AccountError("权限不足", code="AccessDeniedException"),
        ):
            r = self.client.post(
                f"/api/credentials/{self.cid}/regions/ap-east-1/enable",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 400, r.text)
        logs = (
            self.db.query(OperationLog)
            .filter(OperationLog.action == "enable_region")
            .all()
        )
        self.assertEqual(len(logs), 1)
        self.assertEqual(logs[0].status, "failed")
        self.assertEqual(logs[0].region, "ap-east-1")

    def _set_stored_proxy(self, proxy_url: str) -> None:
        cred = self.db.query(AwsCredential).filter_by(id=self.cid).first()
        cred.proxy_url_enc = encrypt_secret(proxy_url)
        self.db.add(cred)
        self.db.commit()

    def test_status_blocked_stored_proxy_400(self):
        # V-2：已存代理使用时重校验拦住时返回 400，不是 500，
        # 也不静默回落直连。
        self._set_stored_proxy("http://proxy.example.com:8080")
        with patch(
            "app.proxy_config._resolve_host_ips", return_value=["127.0.0.1"]
        ):
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 400, r.text)
            self.assertIn("代理不可用", r.json()["detail"])

    def test_status_stored_proxy_rechecked_and_passes(self):
        # V-2 对照：解析结果是公网时正常放行，不影响好代理。
        self._set_stored_proxy("http://proxy.example.com:8080")
        with patch(
            "app.proxy_config._resolve_host_ips", return_value=["93.184.216.34"]
        ), patch(
            "app.routers.credentials.acct.get_region_opt_status",
            return_value="DISABLED",
        ):
            r = self.client.get(
                f"/api/credentials/{self.cid}/regions/ap-east-1/status",
                headers=self._auth(self.token),
            )
            self.assertEqual(r.status_code, 200, r.text)
            self.assertEqual(r.json()["status"], "DISABLED")


if __name__ == "__main__":
    unittest.main()
