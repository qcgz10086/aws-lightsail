import subprocess,json
from pathlib import Path
r=Path('/data/lightsail-t07-implementation');s=r/'source-cd5816a';python='/data/lightsail-t00-revision1/driver-venv/bin/python'
base=[python,'-m','tools.optimization.integration_container','--base-images','/data/lightsail-t00-revision1/container-base-delivery/base-images.json','--samples','20']
for name,commit,tree,source in [('base','024d9d5664fa60a49c4710d129de504bfffbce2c','fb88890457bbd5c89b800562d69602f7617360ec','source-024d9d5'),('candidate','cd5816aa0ab29ca9d692537845687b1bc7060333','8b46c646e498544c8c8ebce78fb23cd85c51a2dd','source-cd5816a')]:
 argv=base+['--source',str(r/source),'--label',commit,'--tree',tree,'--output',str(r/('formal-3-'+name))]
 with (r/('formal-3-'+name+'.log')).open('wb') as log:res=subprocess.run(argv,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 print(name,res.returncode,flush=True)
 if res.returncode:raise SystemExit(res.returncode)
image=json.loads((r/'formal-3-candidate/images.json').read_text())['backend']['id']
commands=[('metrics-3',['/usr/bin/python3','-m','tools.optimization.verify_integration_metrics',str(r/'formal-3-base'),str(r/'formal-3-candidate'),str(r/'formal-3-metrics.json')]),('image-tests-cd5816a',['/usr/bin/python3','-m','tools.optimization.verify_production_image','--image',image,'--source',str(s),'--history',str(r/'test-history'),'--probes',str(r/'image-test-support'),'--output',str(r/'image-tests-cd5816a')]),('rollback-cd5816a',[python,'-m','tools.optimization.paired_rollback','--base-images',str(r/'formal-3-base/images.json'),'--candidate-images',str(r/'formal-3-candidate/images.json'),'--output',str(r/'rollback-cd5816a')])]
for name,argv in commands:
 with (r/(name+'.log')).open('wb') as log:res=subprocess.run(argv,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 print(name,res.returncode,flush=True)
