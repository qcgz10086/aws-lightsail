from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_admin
from app.models import User
from app.password_strength import validate_strong_password
from app.schemas import UserCreate, UserOut, UserUpdate
from app.security import hash_password
from app.services.task_queue import has_unresolved_tasks

router = APIRouter(prefix="/users", tags=["users"])


def _user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        username=user.username,
        is_admin=user.is_admin,
        monthly_limit_gb=user.monthly_limit_gb,
        auto_stop_on_limit_default=bool(getattr(user, "auto_stop_on_limit_default", False)),
        created_at=user.created_at,
        has_credentials=bool(user.credentials),
        credential_count=len(user.credentials or []),
    )


def _validate_user_password(password: str) -> None:
    """R-4：用户密码须满足与实例密码同一强度标准，不满足返回 400。"""
    try:
        validate_strong_password(password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("", response_model=list[UserOut])
def list_users(
    _: User = Depends(get_current_admin),
    db: Session = Depends(get_db),
) -> list[UserOut]:
    users = db.query(User).order_by(User.id.asc()).all()
    return [_user_out(u) for u in users]


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(
    body: UserCreate,
    _: User = Depends(get_current_admin),
    db: Session = Depends(get_db),
) -> UserOut:
    exists = db.query(User).filter(User.username == body.username).first()
    if exists:
        raise HTTPException(status_code=400, detail="用户名已存在")
    _validate_user_password(body.password)
    user = User(
        username=body.username,
        password_hash=hash_password(body.password),
        is_admin=body.is_admin,
        monthly_limit_gb=body.monthly_limit_gb,
        auto_stop_on_limit_default=bool(body.auto_stop_on_limit_default),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return _user_out(user)


@router.patch("/{user_id}", response_model=UserOut)
def update_user(
    user_id: int,
    body: UserUpdate,
    _: User = Depends(get_current_admin),
    db: Session = Depends(get_db),
) -> UserOut:
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    if body.password is not None:
        _validate_user_password(body.password)
        user.password_hash = hash_password(body.password)
        # R-3：管理员重置密码后，该用户此前签发的全部 token 同样失效。
        user.token_version += 1
    if body.is_admin is not None:
        user.is_admin = body.is_admin
    if "monthly_limit_gb" in body.model_fields_set:
        user.monthly_limit_gb = body.monthly_limit_gb
    if "auto_stop_on_limit_default" in body.model_fields_set and body.auto_stop_on_limit_default is not None:
        user.auto_stop_on_limit_default = bool(body.auto_stop_on_limit_default)
    db.add(user)
    db.commit()
    db.refresh(user)
    return _user_out(user)


@router.delete("/{user_id}")
def delete_user(
    user_id: int,
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db),
) -> dict:
    if admin.id == user_id:
        raise HTTPException(status_code=400, detail="不能删除当前登录的管理员")
    db.connection().exec_driver_sql("BEGIN IMMEDIATE")
    if has_unresolved_tasks(db, user_id=user_id):
        raise HTTPException(status_code=409, detail="该用户仍有未完成或待核对任务，完成核对后才能删除")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    db.delete(user)
    db.commit()
    return {"message": "用户已删除"}
